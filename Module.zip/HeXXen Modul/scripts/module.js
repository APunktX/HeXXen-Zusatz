Hooks.once('init', async function() {
    console.log('hexxen-zusatz | init');
});

Hooks.once('ready', async function() {
    console.log('hexxen-zusatz | Hey Na?!');
});
